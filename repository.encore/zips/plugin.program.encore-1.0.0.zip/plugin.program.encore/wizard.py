# wizard.py — Encore Wizard
# Designed to run inside Kodi (xbmc, xbmcgui, xbmcvfs available)

import os
import sys
import time
import shutil
import zipfile
import urllib.request
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon

ADDON = xbmcaddon.Addon()
DIALOG = xbmcgui.Dialog()
PROGRESS = xbmcgui.DialogProgress()

# Dropbox build URL (direct download dl=1)
BUILD_URL = 'https://www.dropbox.com/scl/fi/90rsb9oal9dc3fp3g1l8s/dab19.zip?rlkey=5st59x4bq5xpvljnf0rlflu1z&st=mnvs32to&dl=1'

# Translate Kodi special paths
HOME = xbmc.translatePath('special://home')
TEMP_DIR = xbmc.translatePath('special://home/temp')
BACKUP_DIR = os.path.join(HOME, 'encore_backups')
DOWNLOAD_PATH = os.path.join(TEMP_DIR, 'dab19.zip')
EXTRACT_DIR = os.path.join(TEMP_DIR, 'dab19_extract')

# Helper functions

def ensure_dir(path):
    if not xbmcvfs.exists(path):
        try:
            xbmcvfs.mkdir(path)
        except Exception:
            pass

def confirm_full_install():
    return DIALOG.yesno('Encore Wizard', 'This will install/replace your Kodi build (full build).\\n\\nA backup of your current userdata and addons will be created. Continue?')

def make_backup():
    timestamp = time.strftime('%Y%m%d-%H%M%S')
    backup_path = os.path.join(BACKUP_DIR, 'backup-' + timestamp)
    try:
        ensure_dir(BACKUP_DIR)
        # move userdata and addons into backup folder if they exist
        for name in ('userdata', 'addons'):
            src = os.path.join(HOME, name)
            dst = os.path.join(backup_path, name)
            if xbmcvfs.exists(src):
                try:
                    shutil.move(src, dst)
                except Exception:
                    # On some platforms xbmcvfs doesn't map well for shutil; try fallback copy
                    try:
                        shutil.copytree(src, dst)
                        shutil.rmtree(src)
                    except Exception:
                        pass
        return backup_path
    except Exception as e:
        xbmc.log('EncoreWizard: backup failed: %s' % repr(e))
        return None

def download_build(url, dest):
    ensure_dir(TEMP_DIR)
    if xbmcvfs.exists(dest):
        try:
            xbmcvfs.delete(dest)
        except Exception:
            pass

    dp = PROGRESS
    dp.create('Encore Wizard', 'Downloading build...')
    try:
        def reporthook(blocknum, blocksize, totalsize):
            if totalsize <= 0:
                percent = 0
            else:
                percent = min(int(blocknum * blocksize * 100 / totalsize), 100)
            dp.update(percent, 'Downloading: %s%%' % percent)

        urllib.request.urlretrieve(url, dest, reporthook)
        dp.update(100, 'Download complete')
        time.sleep(0.5)
        dp.close()
        return True
    except Exception as e:
        try:
            dp.close()
        except Exception:
            pass
        xbmc.log('EncoreWizard: download failed: %s' % repr(e))
        DIALOG.ok('Encore Wizard', 'Download failed: %s' % str(e))
        return False

def safe_extract(zip_path, extract_to):
    # Extract zip to extract_to using zipfile
    try:
        if xbmcvfs.exists(extract_to):
            try:
                shutil.rmtree(extract_to)
            except Exception:
                pass
        os.makedirs(extract_to, exist_ok=True)
        with zipfile.ZipFile(zip_path, 'r') as z:
            # Basic safety: prevent path traversal
            for member in z.namelist():
                member_path = os.path.normpath(os.path.join(extract_to, member))
                if not member_path.startswith(os.path.normpath(extract_to)):
                    xbmc.log('EncoreWizard: skipping suspicious member %s' % member)
                    continue
                z.extract(member, extract_to)
        return True
    except Exception as e:
        xbmc.log('EncoreWizard: extract failed: %s' % repr(e))
        return False

def copy_tree(src, dst):
    # Copy extracted tree into HOME, overwriting existing files
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        target_root = os.path.join(dst, rel) if rel != '.' else dst
        if not os.path.exists(target_root):
            try:
                os.makedirs(target_root, exist_ok=True)
            except Exception:
                pass
        for f in files:
            sfile = os.path.join(root, f)
            tfile = os.path.join(target_root, f)
            try:
                shutil.copy2(sfile, tfile)
            except Exception:
                try:
                    # fallback using xbmcvfs
                    with open(sfile, 'rb') as fh:
                        data = fh.read()
                    with xbmcvfs.File(tfile, 'wb') as out:
                        out.write(data)
                except Exception:
                    xbmc.log('EncoreWizard: failed copy %s' % tfile)

def cleanup():
    try:
        if xbmcvfs.exists(DOWNLOAD_PATH):
            xbmcvfs.delete(DOWNLOAD_PATH)
    except Exception:
        pass
    try:
        if os.path.exists(EXTRACT_DIR):
            shutil.rmtree(EXTRACT_DIR)
    except Exception:
        pass

def main():
    # Confirm
    if not confirm_full_install():
        return

    # Backup
    xbmc.log('EncoreWizard: creating backup...')
    backup_path = make_backup()
    if backup_path:
        xbmc.log('EncoreWizard: backup at %s' % backup_path)
    else:
        xbmc.log('EncoreWizard: backup not available')

    # Download
    ok = download_build(BUILD_URL, DOWNLOAD_PATH)
    if not ok:
        return

    # Extract
    xbmc.log('EncoreWizard: extracting...')
    ok = safe_extract(DOWNLOAD_PATH, EXTRACT_DIR)
    if not ok:
        DIALOG.ok('Encore Wizard', 'Failed to extract build')
        cleanup()
        return

    # Copy into HOME
    xbmc.log('EncoreWizard: installing build...')
    copy_tree(EXTRACT_DIR, HOME)

    cleanup()

    # Finalize
    DIALOG.ok('Encore Wizard', 'Install complete. Kodi will now restart to apply changes.')
    xbmc.executebuiltin('RestartApp')

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        xbmc.log('EncoreWizard: unexpected error: %s' % repr(e))
        DIALOG.ok('Encore Wizard', 'An unexpected error occurred: %s' % repr(e))
