# Simple downloader for the Encore build ZIP.
# NOTE: This addon is intentionally written to only download the ZIP to Kodi's packages folder.
# It DOES NOT automatically extract or overwrite Kodi userdata/configuration.
import xbmc, xbmcgui, xbmcaddon
import urllib.request, os, sys

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')

url = "https://www.dropbox.com/scl/fi/90rsb9oal9dc3fp3g1l8s/dab19.zip?rlkey=5st59x4bq5xpvljnf0rlflu1z&st=vbsb6tda&dl=1"
path = xbmc.translatePath('special://home/addons/packages/')
if not os.path.exists(path):
    os.makedirs(path, exist_ok=True)
zip_file = os.path.join(path, 'dab19.zip')

xbmcgui.Dialog().notification(addonname, 'Starting download of Encore build...', xbmcgui.NOTIFICATION_INFO, 4000)
try:
    urllib.request.urlretrieve(url, zip_file)
    xbmcgui.Dialog().ok(addonname, 'Download complete', 'Saved to: ' + zip_file)
except Exception as e:
    xbmcgui.Dialog().ok(addonname, 'Download failed', str(e))
    sys.exit(1)
